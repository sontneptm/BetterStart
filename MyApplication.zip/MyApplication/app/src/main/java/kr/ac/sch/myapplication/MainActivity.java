package kr.ac.sch.myapplication;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity
{
    static final String serverIP = "192.168.0.92";
    static final int serverPort = 8080;    //포트번호
    Socket inetSocket = null;
    private EditText mEt;
    private EditText mEt2;
    TextView tv1;
    TextView tv2;
    TextView tv3;
    TextView tv4;
    String usCheck;
    String temperature;
    String humidity;
    String detect;
    Listen listener;
    boolean isWriting =false;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initData();
        SocketInit socketStart = new SocketInit();
        socketStart.start();

    }

    public void initData()
    {
        mEt = (EditText) findViewById(R.id.EditText01);
        mEt2 = (EditText) findViewById(R.id.editText2);
        tv1 = (TextView) findViewById(R.id.textView5);
        tv2  = (TextView) findViewById(R.id.textView6);
        tv3 = (TextView) findViewById(R.id.textView7);
    }

    public void onClickBtn(View v)
    {

        Toast toast = Toast.makeText(getApplicationContext(), mEt.getText().toString(),0);
        toast.show();

        TCPclient tcpThread = new TCPclient(mEt.getText().toString());
        Thread thread = new Thread(tcpThread);
        thread.start();

    }

    private class SocketInit extends Thread{
        private String return_msg;
        @Override
        public void run() {
            try {
                Log.d("TCP", "C: Connecting...");
                inetSocket = null;
                inetSocket = new Socket(serverIP, serverPort);
                //inetSocket.connect(socketAddr);\


                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(inetSocket.getInputStream()));
                    while (true) {

                        while(isWriting){
                        }

                        return_msg = in.readLine();

                        if(return_msg!=null) {
                        usCheck = return_msg.substring(0,return_msg.indexOf(','));
                        if(usCheck.trim().equals("us= 1")){
                            detect = "감지됨!";
                        }
                        else if(usCheck.trim().equals("us= 0")){
                            detect = "아무도 없어요";
                        }
                        humidity = return_msg.substring(return_msg.indexOf(',')+1,return_msg.lastIndexOf(','));
                        temperature = return_msg.substring(return_msg.lastIndexOf(',')+1);

                            mEt2.setText("connectd!");
                            tv1.setText(humidity);
                            tv2.setText(temperature);
                            tv3.setText(detect);
                        }

                        sleep(100);
                    }
            }
            catch (Exception ex){
                Log.e("TCP", "C: Error2", ex);
            }
        }
    }

    private class TCPclient implements Runnable
    {
        private String msg;


        // private String return_msg;
        public TCPclient(String _msg)
        {
            this.msg = _msg;
        }

        public void run()
        {
            // TODO Auto-generated method stub
                try
                {
                    isWriting=true;
                    Log.d("TCP", "C: Sending: '" + msg + "'");
                    PrintWriter out = new PrintWriter(new BufferedWriter(
                            new OutputStreamWriter(inetSocket.getOutputStream())), true);
                    out.println(msg);

                    isWriting = false;
                   ///BufferedReader in = new BufferedReader(
                         //   new InputStreamReader(inetSocket.getInputStream()));
                   // return_msg = in.readLine();


                }
                catch (Exception e)
                {
                    Log.e("TCP", "C: Error2", e);
                }
        }
    }

    private class Listen extends Thread
    {
        private String return_msg;

        // private String return_msg;

        public void run()
        {
                // TODO Auto-generated method stub
                try {
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(inetSocket.getInputStream()));
                    while (true) {
                        return_msg = in.readLine();

                        Log.d("TCP", "C: Server send to me this message -->"
                                + return_msg);

                        sleep(10);
                    }
                } catch (Exception e) {
                    Log.e("TCP", "C: Error2", e);
                }
        }
    }
}

